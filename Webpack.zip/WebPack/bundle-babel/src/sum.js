const sum = (a, b) => a + b;
export default sum;